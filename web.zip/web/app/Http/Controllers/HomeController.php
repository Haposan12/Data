<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('home');
    }

   

    public function stem(Request $request){
        $word = $request->keyword;
        $query = DB::table('kata_dasar')->where('kata', $word)->get();

        $awalan = array("di","ke","se","ter","me","mem","men","meng","meny","pe","pem","pen","peng","peny",
          "ber","bel","be","per","pel","pe");

        $akhiran = array("i","kan","an","kah","lah","tah","pun","ku","mu","nya");

        $indexAwalan = array();
        $indexAkhiran = array();
        $root = array();
        $hasil = array();
        $hasil2 = array();

        foreach ($query as $key => $row) {
            # code...
            $kataId = $row->id;
        }

        if(!empty($kataId)){
           $hasil2 = $word; 
        }else{
            for($x = 0;$x<5;$x++){
                $start = substr($word, 0,$x);
                if(in_array($start, $awalan)){
                    array_push($indexAwalan, $x);
                }
            }
            for($x=1;$x<4;$x++){
                $l = strlen($word);
                $end = substr($word, $l-$x, $l);
                if(in_array($end, $akhiran)){
                    array_push($indexAkhiran, $x);
                }
            }

            if(count($indexAwalan) != 0){
                for($x=0;$x<count($indexAwalan);$x++){
                    $prefix = substr($word,0,$indexAwalan[$x]);
                    $key = substr($word, $indexAwalan[$x], strlen($word));
                    if($prefix == "meng" || $prefix == "peng"){
                        $key1 = "k".$key;
                        array_push($root, $key1);
                        array_push($root, $key);
                    }else if($prefix == "men" || $prefix == "pen"){
                        $key1 = "t".$key;
                        array_push($root, $key1);
                        array_push($root, $key);
                    }else if($prefix == "meny" || $prefix == "peny"){
                        $key1 = "s".$key;
                        array_push($root, $key1);
                        array_push($root, $key);
                    }else if($prefix == "mem" || $prefix == "pem"){
                        $key1 = "p".$key;
                        array_push($root, $key1);
                        array_push($root, $key);
                    }else{
                        $key = $key;
                        array_push($root,$key);
                    }
                }
                if(count($indexAkhiran) != 0){
                    foreach ($root as $kata) {
                        for($x=0;$x<count($indexAkhiran);$x++){
                            $key = substr($kata,0,strlen($kata)-$indexAkhiran[$x]);
                            array_push($hasil,$key);
                        }
                    }
                }else{
                    $hasil = $root;
                }
            }else{
                if(count($indexAkhiran) != 0){
                    for($x=0;$x<count($indexAkhiran);$x++){
                        $key = substr($word,0,strlen($word)-$indexAkhiran[$x]);
                        array_push($hasil,$key);
                        array_push($hasil,$word);
                    }
                }else{
                    array_push($hasil,$word);
                }
            }

        
            $result = array_merge($hasil,$root);
            foreach ($result as $kata ) {
                $query = DB::table('kata_dasar')->where('kata',$kata)->get();
                foreach ($query as $key) {
                    # code...
                    if($key->kata != null){
                        $hasil2= $key->kata;
                    }else{
                        $hasil2 = "string";
                    }
                }
            }

        }
        //echo count($indexAwalan);
        return view('home.index', compact('hasil2','word'));
    }
}
