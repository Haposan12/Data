
@extends('layouts.app')

@section('content')
<div class="search">
    <form method="POST" enctype="multipart/form-data" action="{{ route('stem') }}">
        {{ csrf_field() }}
        <input type="search" name="keyword" value="<?php if(!empty($word)){echo $word;} ?>" id="search">
        <button type="submit" id="button" class="button-primary">Stem</button>
    </form>
</div>

<div>
	<?php
		$awalan = array("di","ke","se","ter","me","mem","men","meng","meny","pe","pem","pen","peng","peny",
          "ber","bel","be","per","pel","pe");

        $akhiran = array("i","kan","an","kah","lah","tah","pun","ku","mu","nya");

		$indexAwalan = array();
		$indexAkhiran = array();

		if(!empty($hasil2)){
			for($x = 0;$x<5;$x++){
                $start = substr($word, 0,$x);
                if(in_array($start, $awalan)){
                    array_push($indexAwalan, $x);
                }
            }
            for($x=1;$x<4;$x++){
                $l = strlen($word);
                $end = substr($word, $l-$x, $l);
                if(in_array($end, $akhiran)){
                    array_push($indexAkhiran, $x);
                }
            }
            if(count($indexAwalan) != 0){
            	for($x=0;$x<count($indexAwalan);$x++){
            		$prefix = substr($word,0,$indexAwalan[$x]);
            		if(substr($word, $indexAwalan[$x]) == $hasil2){
            			$a = $prefix;
            		}
            		else{
            			if(count($indexAkhiran) != 0){
	            			for($y=0;$y<count($indexAkhiran);$y++){
		            			$root = substr($word, $indexAwalan[$x], -$indexAkhiran[$y]);
		            			$suffix = substr($word, strlen($word)-$indexAkhiran[$y], strlen($word));
		            			if($root == $hasil2){
		            				$a = $prefix;
		            				$b = $suffix;
		            			}else{
		            				if($prefix == "meny" || $prefix == "peny"){
		            					if("s".$root == $hasil2){
		            						$a = $prefix;
		            						$b = $suffix;
		            					}
		            				}else if($prefix == "men" || $prefix == "pen"){
		            					if("t".$root == $hasil2){
		            						$a = $prefix;
		            						$b = $suffix;
		            					}
		            				}else if($prefix == "mem" || $prefix == "pem"){
		            					if("p".$root == $hasil2){
		            						$a = $prefix;
		            						$b = $suffix;
		            					}
		            				}
		            			}

		            		}
	            		}	
            		}
            		
            		
            	}
            }else{
            	for($x=0;$x<count($indexAkhiran);$x++){
            		$suffix = substr($word, strlen($word)-$indexAkhiran[$x], strlen($word));
            		$root = substr($word, 0, -$indexAkhiran[$x]);
            		if($root == $hasil2){
            			$b = $suffix;
            		}
            	}
            }
            
           	

            if(!empty($a)){
            	echo "Awalan : ".$a."-";
            }else{
            	echo "Awalan : -";
            }
			echo "<br/>";
			if(!empty($b)){
				echo "Akhiran : "."-".$b;
			}else{
				echo "Akhiran : -";
			}
			echo "<br/>";
			echo "Kata dasar :"." ".$hasil2;
			
			
		}
	?>
</div>

<script type="text/javascript">
		
	
</script>